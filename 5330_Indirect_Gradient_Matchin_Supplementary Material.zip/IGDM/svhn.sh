GPU_ID=3


method=ard_IGDM
alpha=0
beta=1
gamma=1
epochs=50
teacher=LTD
student=RES-18

nowand=1
wandb_project=wandb_entity
wandb_entity=wandb_entity


for alpha in 50
do
    CUDA_VISIBLE_DEVICES=$GPU_ID python ${method}_svhn.py --wandb_name ${method}_${alpha}_${beta}_${gamma}_${epochs}_${student}_svhn --alpha $alpha --beta $beta --gamma $gamma --nowand $nowand --wandb_project $wandb_project --wandb_entity $wandb_entity --method $method --epochs $epochs --teacher $teacher --student $student --dataset svhn
done

