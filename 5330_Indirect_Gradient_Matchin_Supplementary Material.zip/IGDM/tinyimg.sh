GPU_ID=2

method=ard_IGDM
alpha=0
beta=0
gamma=0
epochs=100
teacher=RiFT
student=RES-18

nowand=1
wandb_project=wandb_entity
wandb_entity=wandb_entity

for alpha in 10
do
    CUDA_VISIBLE_DEVICES=$GPU_ID python resnet18_${method}_tinyimg.py --wandb_name ${method}_${alpha}_${beta}_${gamma}_${epochs}_${adaptive} --alpha $alpha --beta $beta --gamma $gamma --nowand $nowand --wandb_project $wandb_project --wandb_entity $wandb_entity --method $method --epochs $epochs --teacher $teacher --student $student  --adaptive $adaptive --dataset tinyimg
done